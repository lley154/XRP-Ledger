package com.contextsolutions.assetmanager.ui.controller;

import javafx.fxml.FXML;

public class MarketTickerController {

  @FXML
  private void handleMarketClick() {
    System.out.println("Market clicked");
  }
}