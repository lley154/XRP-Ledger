package com.easya.assetmanager.ui.controller;

import javafx.fxml.FXML;

public class ReportingController {

  @FXML
  private void handleTransferClick() {
    // Handle transfer click - you might want to create a separate transfer.fxml
    System.out.println("Transfer clicked");
  }
}